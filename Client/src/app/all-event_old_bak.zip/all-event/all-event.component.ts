import { Component, OnInit } from '@angular/core';
import { DataService } from '../model/data.service';

@Component({
  selector: 'app-all-event',
  templateUrl: './all-event.component.html',
  styleUrls: ['./all-event.component.css']
})
export class AllEventComponent implements OnInit {

  public data1 = [];

  constructor(private _dataService: DataService) { }

  ngOnInit() {
    console.log("s=========");
    this._dataService.getAllItem().subscribe(data => this.data1 = data);     
    console.log(this.data1);
    console.log("e=========");
  }

}
